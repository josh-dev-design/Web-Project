const router = require('express').Router();
const Post = require('../model/post')

router.post('/', (req, res) =>{
    const post = new Post ({
        title: req.body.title
    });


    post.save()
    .then(data => {
        res.status(201).json(data)
    })
    .catch( err =>{
        res.status(400).send( {message: err})
    });
});

module.exports = router