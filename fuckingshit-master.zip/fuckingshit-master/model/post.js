const mongoose = require('mongoose');

const PostSChema = mongoose.Schema({
    title: {
        type: String,
        required: true
    }
})

module.exports = mongoose.model('post', PostSChema);