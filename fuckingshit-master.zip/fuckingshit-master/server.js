const express = require('express')
const mongoose = require('mongoose')
require('dotenv/config');
const bodyparser = require('body-parser');
const app = express();

app.use(bodyparser.urlencoded({ extended : true}))
app.use(bodyparser.json())
mongoose.connect(process.env.connected, {useNewUrlParser: true}, () => 
    console.log('connected to db'))

app.get('/',(req, res) =>{
    res.send('Hello world')
})
const post = require('./routes/post')
app.use('/post', post)

app.listen(3000, () => console.log('Server is running'))