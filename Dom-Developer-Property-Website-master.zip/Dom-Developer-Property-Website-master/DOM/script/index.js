 const req = 'script/index.json';

 async function xx(){

     const request = await fetch(req);
     const respond = await request.json();


   document.getElementById('firstFounder-Name').textContent = respond.co1.Name
   document.getElementById('firstFounder-title').textContent = respond.co1.title

   
   document.getElementById('secondFounder-Name').textContent = respond.co3.Name
   document.getElementById('secondFounder-title').textContent = respond.co3.title

   
   document.getElementById('thirdFounder-Name').textContent = respond.co2.Name
   document.getElementById('thirdFounder-title').textContent = respond.co2.title    


 }
 xx();

 function clickLink(){
   window.location.href = 'http://www.google.com'
 }

const blmDiv = document.getElementById('close');
blmDiv.addEventListener('click', () =>{
  const blmDiv = document.getElementById('blm');
  blmDiv.closest('div').remove();
});
