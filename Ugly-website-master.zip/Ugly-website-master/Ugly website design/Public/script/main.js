function rt(){

    let cl = new Date();

    let h = cl.getHours();
    let m = cl.getMinutes();
    let s = cl.getSeconds();

    let ap = (h < 12) ? "AM" : "PM"
    h = ( h > 12 ) ? h-12 : 2;

    h = ("0" + h).slice(-2);
    m = ("0" + m).slice(-2);
    s = ("0" + s).slice(-2);

    document.getElementById('time').innerHTML =
     h + " : " + m + " : " + s + " " + ap;
    
    setTimeout(rt, 500);
}
const x = document.querySelector('footer');

