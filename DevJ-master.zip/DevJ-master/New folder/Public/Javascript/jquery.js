
function cick(){ 
    window.location.href ="https://github.com/josh-dev-design";
}

