const express = require('express');
const { request } = require('express');
const app = express();

app.use(express.static('public'));
app.use(express.json({limit: '2mb'}));



app.post('/api', (req, res) =>{
    console.log(req.body);
    const data = req.body;
    res.json({
        status: 'Status',
        latitude: data.lat,
        longitude: data.long,
    })
});

app.listen(3000, ()=> console.log('Server is running at port http://localhost:3000'))