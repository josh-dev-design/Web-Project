
const loginBtn = document.getElementById('submit');


loginBtn.addEventListener('click', submitBtn)

function submitBtn(e){
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const  p = document.querySelector('.escp');
        if( username == "admin" && password =="admin123"){
            p.innerHTML = "Success";
            p.style.color ="green";
            return false;
        }
        else{
            p.innerHTML = "Invalid email or passowrd. Retry again"
            p.style.color = 'red';
    }
}

